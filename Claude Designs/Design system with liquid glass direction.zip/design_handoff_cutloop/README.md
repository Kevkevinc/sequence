# Handoff: Cutloop — UGC AI Video Editor (Web App)

## Overview
Cutloop is a web app for UGC (user-generated content) creators. A creator uploads
raw phone footage of themselves trying on / using a product; the backend AI picks
the cuts, writes a short hook caption, burns it in, and returns several ready-to-post
**vertical (9:16, TikTok/Reels)** videos. **Every exported video is muted by design** —
creators record voiceover afterward.

This package documents the full front end: five screens plus global chrome (sidebar
nav, toast) and a signature **Liquid Glass** visual treatment.

## About the Design Files
The files in this bundle are **design references created in HTML** — a working
prototype that shows the intended look, layout, and behavior. They are **not
production code to copy directly.**

`Cutloop.dc.html` is authored in a bespoke streaming component format (a custom
`<x-dc>` runtime backed by `support.js`); do **not** try to ship it or reuse
`support.js`. Your task is to **recreate these screens in the target codebase's
environment** (React, Vue, Svelte, etc.) using its established patterns, component
library, and state tooling. If no front end exists yet, choose an appropriate stack
(React + Vite + CSS Modules/Tailwind is a fine default) and build there.

The prototype simulates the backend (setTimeout-driven job progress). In production,
replace the simulation with real API calls + polling (see **State Management**).

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, and interactions are final and
intentional. Recreate the UI pixel-closely. The one thing to treat as "reference, tune
in real browser" is the Liquid Glass SVG filter — exact displacement values are taste,
documented below with sensible defaults.

---

## Design Tokens

### Fonts (Google Fonts)
- **Bricolage Grotesque** — display / headings. Weights 600, 700, 800. Tight tracking
  (`letter-spacing: -0.02em`) on large headings.
- **Manrope** — body, UI labels, buttons, inputs. Weights 400–800.
- **Space Mono** — eyebrows, monospace labels, meta, the burned-in overlay text,
  numeric chips. Weights 400, 700. Letter-spacing 0.05–0.18em, often uppercase.

### Color — base / surfaces
| Token | Value | Use |
|---|---|---|
| App backdrop | `radial-gradient(120% 120% at 50% -10%, #141824 0%, #0b0d13 55%, #08090d 100%)` | Page behind the app frame |
| Frame inner | `linear-gradient(180deg, rgba(18,20,28,.32), rgba(10,11,16,.46))` | Inside the rounded app window |
| Frame radius | `31px` (outer wrapper `32px`, `1px` padding gradient border) | App window |
| Text primary | `#ffffff` | Headings, key labels |
| Text secondary | `rgba(255,255,255,.5–.62)` | Body, meta |
| Text faint | `rgba(255,255,255,.4)` | Hints, helper text |
| Hairline | `rgba(255,255,255,.08)` | Dividers, section rules |

### Color — accent (themeable)
- **Default accent: `#e5544b`** (coral-red). Used for the primary buttons, active nav,
  eyebrows, toggles, focus rings, pipeline dots, slider fill, the ambient light tint.
- Ship it as a single theme variable (`--accent`). Curated options offered in the
  prototype: `#4d8dff` `#2fb8a0` `#e0994a` `#e5687a` `#4bbf73` `#35c4dd` `#6d78f0`
  `#ec5f8b` `#e5544b` `#b07d3a`.

### Color — status (badges, dots, pipeline)
| Status | Text/dot color | Bg | Border |
|---|---|---|---|
| Ready (done) | `oklch(.84 .15 155)` green | `rgba(80,220,150,.15)` | `rgba(120,240,180,.34)` |
| Rendering | `oklch(.8 .12 235)` blue | `rgba(190,130,255,.16)`* | `rgba(210,160,255,.38)`* |
| Queued / Tagging / Planning | `oklch(.86 .1 90)` amber | `rgba(255,210,130,.14)` | `rgba(255,215,150,.3)` |
| Failed | `oklch(.76 .17 22)` red | `rgba(255,110,110,.15)` | `rgba(255,140,140,.38)` |

\*Rendering badge bg/border still carries a faint violet from an earlier palette —
normalize to the blue family (`rgba(90,150,255,…)`) when you rebuild.

Rendering/queued/tagging/planning dots **pulse** (opacity + scale, 1.3s ease-in-out).

### Video placeholder (thumbnails + players)
Vertical **9:16** blocks. Fill: `linear-gradient(160deg, oklch(.5 .1 H), oklch(.33 .08 (H+50)))`
with a slow `filmpan` background-position drift (9s alternate). Each variation uses a
different hue `H`. Overlays on the block: a `MUTED` mono chip (top-left), a stacked
**sizing overlay** (height / weight / "Size X", mono, bottom-right, or bottom-left in
the "Dupe Flip" style), a centered glass play button, a bottom scrim
`linear-gradient(transparent, rgba(0,0,0,.6))`, and the hook caption in Bricolage 800.

### Radii / shadow / spacing
- Radii: pills `999px`; inputs `12–16px`; cards `20–26px`; app frame `31px`.
- Card shadow: `inset 0 1px 0 rgba(255,255,255,.4–.5)` (top specular) + `0 10–16px 26–44px rgba(0,0,0,.3–.44)`.
- Card border: `1px solid rgba(255,255,255,.17–.2)`.
- Content padding: page gutters `28–30px`; card padding `13–30px`; gaps `10–28px` via fl?ex/grid `gap`.

---

## The Liquid Glass treatment (signature effect)
Glass panels don't just blur — they **refract** the light/content behind them like a
water droplet, with a faint chromatic (RGB) fringe at the edges.

**How it's built (recreate with an inline SVG filter + `backdrop-filter`):**
```
backdrop-filter: url(#liquid-glass) blur(var(--frost)) saturate(var(--sat)) brightness(var(--bright));
```
SVG filter `#liquid-glass`:
1. `feTurbulence type="fractalNoise"` → organic ripple (baseFrequency ≈ `0.0084 0.0126`).
2. `feGaussianBlur` on the noise (stdDeviation ≈ `1.7`) to smooth it.
3. **Three** `feDisplacementMap` passes on `SourceGraphic` at slightly different `scale`
   values — one per channel — isolated via `feColorMatrix` (R, G, B) and recombined with
   `feBlend mode="screen"`. The scale spread between channels **is** the chromatic
   dispersion / rainbow fringe.

**Tunable parameters** (expose as settings; defaults the design shipped with):
| Setting | Default | Maps to |
|---|---|---|
| Light | 1.5 | backdrop `brightness` (`0.96 + light*0.12`) + `saturate` (`1.4 + light*0.5`) |
| Refraction | 55 | base `feDisplacementMap` scale (green/mid channel) |
| Depth | 1 | multiplier on all channel scales (magnification/thickness) |
| Dispersion | 4 | scale spread between R (base+d) and B (base−d) channels |
| Frost | 6px | `backdrop-filter: blur()` amount |
| Splay | 1.4 | turbulence baseFrequency × splay; noise blur = `2.4/splay` (edge sharpness) |
| Glass | 0.04 | white tint alpha of the panel fill |

Panel fill (tint over the refraction):
`linear-gradient(155deg, rgba(255,255,255, glass+0.07), rgba(255,255,255, glass))`.

**Ambient light** (what the glass refracts): two large, soft, wide **near-white**
radial fields inside the frame — `oklch(.97 0 0)`, opacity ~`.26` and ~`.20`,
`blur(120–130px)`, `pointer-events:none`. This monochrome light is deliberate; do not
reintroduce multi-hue gradients. The refraction/fringe is strongest where a panel edge
crosses one of these light fields (see the Your Videos screenshot).

> Note: `backdrop-filter: url(#svg)` refraction works in Chromium. In Safari/Firefox it
> may degrade to plain blur — provide `blur()+saturate()` as the graceful fallback.

---

## Global chrome

### Left sidebar (fixed, width 246px)
- Brand: `C` mark (accent square, 38px, radius 12, inset white top highlight) + "Cutloop"
  (Bricolage 800, 19px) with mono sub-label "UGC AI EDITOR".
- Nav items: Home, Your videos, New video, Profile. Each is a full-width button, icon +
  label (Manrope 700, 14.5px), radius 14. **Active** = `rgba(255,255,255,.12)` fill +
  inset top highlight; inactive text `rgba(255,255,255,.55)`.
- "SILENT BY DESIGN" callout card (amber-tinted): speaker-mute icon + "Every export is
  muted by default. Add your voiceover after."
- Bottom: user chip (avatar `A`, "avery.makes", "Pro creator").

### Top bar (per screen)
- Left: page title (Bricolage 800, 25px) + subtitle (13.5px, secondary).
- Right: primary "＋ New video" button (accent, radius 14) — shown on every screen
  except New Video itself.

### Toast
Bottom-center pill, `rgba(30,20,44,.85)` + blur, accent check chip + message. Auto-dismiss
~2s. Slides up in (`toastin`). Fires on: video download, "Download all", profile save.

---

## Screens / Views

### 1. Home  (`screenshots/01-home.png`)
**Purpose:** Landing / workspace overview; entry to create.
**Layout:** `max-width:1000px`. Top: a 2-column grid `minmax(0,1.4fr) 244px`, gap 26.
- **Left hero card** (glass): mono eyebrow "FOR UGC CREATORS" (accent); H2 "Your footage,
  cut and captioned." (Bricolage 800, 38px); paragraph (see copy); a 3-stat row
  (videos / ready / rendering — Bricolage 800, 28px numbers, "rendering" count in blue);
  accent "＋ New video" button pinned to the card bottom.
- **Right preview** (9:16 video placeholder, vertical): MUTED chip, "Size worn M" mono
  chip, centered play, hook caption, scrim.
- Below the grid: "Recent videos" header + "See all →" (accent), then a responsive card
  grid `repeat(auto-fill, minmax(228px,1fr))` of job cards.
**Job card:** vertical `54×96` thumbnail (spinner overlay if in-progress) + title
(Bricolage 800, 14.5px, truncated) + meta ("30s · Mixed Cuts") + status badge. Hover:
border brightens to `rgba(255,255,255,.26)`. Whole card navigates to detail.

### 2. New Video  (`screenshots/02-new-video.png`)
**Purpose:** Configure and submit a render job.
**Layout:** 2-column grid `minmax(0,1fr) 336px`, gap 28, `max-width:1040px`. Left = form,
right = sticky live summary rail.
**Left form:**
- **Upload dropzone** (dashed glass label): up-arrow icon, "Drop your raw clips",
  subtext "Phone footage of you trying on / using the product". On file select shows an
  accent pill "N clips ready". Accepts `video/*`, multiple.
- **Glass form card** with sections separated by hairlines:
  - **Product name** — text input; helper "Use the real product name — it feeds the
    AI-written hook." Inline validation error if empty on submit (red).
  - **Show sizing info** — label + description "Burns a small 'size worn' overlay onto
    every video" + a **toggle** (track goes accent when on, 48×28, knob translates 20px).
    When on, reveals a "size worn" text input (e.g. "M" or "runs small").
  - **Length** — 4-item segmented control: 15s / 30s / 45s / 60s. Active segment =
    raised light fill + inset highlight.
  - **Mode** — 2 large tab buttons: **Custom** ("You set the pacing") vs **Style**
    ("Named presets"). Active tab raised.
    - If **Custom** → **Pacing** segmented control: Slow / Medium / Fast.
    - If **Style** → list of style cards (radio-like, accent ring + filled check when
      selected): **Mixed Cuts** ("Quick cuts mixing b-roll and try-on footage. Sizing
      sits bottom-right."), **Dupe Flip** ("Fast declarative cuts, bold caption, sizing
      bottom-left. Composites in an inspiration photo." — tagged `+ INSPIRATION PHOTO`).
      Selecting Dupe Flip reveals an **Inspiration photo** upload row (`image/*`).
  - **Variations** — range slider 1–10 (accent-filled track, white thumb w/ accent ring);
    big Bricolage number readout; helper "Different edits generated from the same footage."
**Right summary rail (sticky):** mono "PREVIEW" label; a fixed vertical 9:16 preview
(174×309) showing MUTED chip, the stacked sizing overlay (live from Profile H/W + chosen
size), scrim, and the product name as caption; a key/value list (Length, Mode,
Pacing/Style, Variations, Sizing) that updates live; a "Generate videos" accent button;
caption "Renders in the background. You'll see live progress."
**Submit:** validates product name → creates a job (status `pending`) → navigates to its
detail → simulated pipeline begins.

### 3. Your Videos  (`screenshots/03-your-videos.png`)
**Purpose:** All jobs.
**Layout:** responsive grid `repeat(auto-fill, minmax(300px,1fr))`, gap 16.
**Job card (list variant):** vertical `66×117`-ish thumbnail (spinner if in-progress) +
title (Bricolage 800, 16px) + meta ("30s · Mixed Cuts · 3 variations") + status badge +
right chevron. Hover: lifts `translateY(-2px)` + border brightens.
**Empty state** (when no jobs): centered glass icon tile, "No videos yet", "Upload a clip
and Cutloop sends back a few cuts ready to post.", accent "Create your first video" button.

### 4. Video Detail  (`screenshots/04-video-detail.png`)
**Purpose:** Live status + results for one job.
**Layout:** 2-column grid `352px minmax(0,1fr)`, gap 28, left column sticky.
**Left info card (glass):** "‹ All videos" back button; product title (Bricolage 800,
23px); status badge; meta line; conditional banners:
- **Live** (in-progress): green pulsing dot + "Live — refreshing every 5s".
- **Warning** (amber): e.g. "Style config had a problem — fell back to default pacing."
- **Failure** (red): e.g. "Not enough usable footage — clips were too short to plan cuts."
- **Pipeline** timeline: Queued → Tagging clips → Planning cuts → Planned → Rendering →
  Done. Each step a dot + label; completed = accent dot + connecting line filled; active =
  glowing pulsing accent dot + "in progress" note; upcoming = faint; failed stage = red dot.
**Right results:** header "Variations" + **"Download all (N)"** accent button (shown when
≥1 variation is done). Grid `repeat(auto-fill, minmax(215px,1fr))`, gap 18, of variation
cards. Each variation card (glass) shows `VAR n` + per-variation status badge, and one of:
- **Done:** 9:16 player (MUTED chip, stacked sizing overlay, play, scrim, AI hook caption),
  duration row (clock + "28s"), full-width "Download" button (toast on click).
- **Rendering:** shimmering 9:16 skeleton + spinner + "Rendering & burning in the hook…".
- **Pending:** dashed 9:16 tile + pulsing dot + "Waiting in queue".
- **Failed:** red-tinted 9:16 tile + error icon + reason.

> Known nit in the prototype: a fully-done job renders the final "Done" pipeline step as
> `active` with an "in progress" note. When you rebuild, treat a `done` job's last step as
> completed (no pulse/note).

### 5. Profile  (`screenshots/05-profile.png`)
**Purpose:** Personal measurements that feed the burned-in sizing overlay.
**Layout:** `max-width:520px`. One grouped glass card with **Height** and **Weight** text
inputs (divided by a hairline). Accent **Save** button (toast "Profile saved"). Info row:
"Sign-in & account are handled securely by Clerk, nothing to manage here." (Auth is out of
scope for this screen — assume Clerk handles it elsewhere.)

---

## Exact copy (use verbatim)
- Home eyebrow: **FOR UGC CREATORS**
- Home H2: **Your footage, cut and captioned.**
- Home body: **Upload your try-on footage. The AI picks the cuts, writes the hook, and
  burns it in. As many variations as you want, no editing.**
- Sidebar callout: **SILENT BY DESIGN** / "Every export is muted by default. Add your
  voiceover after."
- New Video subtitle: "Upload footage and let the AI cut it"
- Product-name helper: "Use the real product name — it feeds the AI-written hook."
- Sizing helper: "Burns a small 'size worn' overlay onto every video"
- Variations helper: "Different edits generated from the same footage."
- Summary footer: "Renders in the background. You'll see live progress."
- Empty state: "No videos yet" / "Upload a clip and Cutloop sends back a few cuts ready to post."
- Live banner: "Live — refreshing every 5s"
- Example hooks (AI-generated, per variation): "POV: you found the hoodie that goes with
  everything", "the zip-up that sold out three times", "honest fit check on the viral hoodie",
  "run don't walk to these cloud runners", "the sneaker that feels like a pillow",
  "the $40 dupe that looks $400".

---

## Interactions & Behavior
- **Navigation:** sidebar + top-bar buttons switch screens; job cards open detail; "‹ All
  videos" returns to the list. Screen changes play a `screenin` fade/slide-up (0.42s).
- **New Video form:** all controls are live and reflected in the summary rail instantly
  (mode/pacing/style, length, sizing on/off + value, variations count, product name).
- **Mode branching:** Custom shows Pacing; Style shows style cards; Dupe Flip reveals the
  inspiration-photo uploader.
- **Submit:** requires product name (else inline red error). Creates job → detail →
  pipeline animation.
- **Simulated job lifecycle (replace with real API):** status advances
  `pending → tagging → planning → planned → rendering → done`, ~1.5s per step. While
  `rendering`, variations flip one-by-one from `pending → rendering → done`; on done, a
  hook is generated and a duration assigned. Seed data also includes a `rendering` job and
  two `failed` examples (one whole-job failure, one single-variation failure + a
  fell-back-to-default warning).
- **Downloads:** per-variation "Download" and header "Download all (N)" both fire a toast
  (wire to real file download / zip in production).
- **Animations:** `filmpan` (thumb gradient drift, 9s), `shimmer` (render skeleton, 1.4s),
  `spin` (spinners, 0.9s), `pulseDot` (status dots, 1.3–1.4s), `liveDot` (live ring, 1.6s),
  `screenin`, `toastin`. Respect `prefers-reduced-motion` when you rebuild.
- **Hover:** buttons brighten (`filter: brightness(1.06)`), cards brighten border / lift.
- **Focus:** inputs set `border-color: accent` on focus.

---

## State Management
Prototype state (lift into your store / server state as noted):
- `screen` — `home | new | jobs | detail | profile` (route this instead).
- `currentId` — selected job id for detail (route param `/videos/:id`).
- `jobs[]` — **server state**; fetch list + single job. Each job:
  `{ id, productName, length, mode, pacing, styleId, styleName, variationCount, status,
  warning, failureReason, sizeWorn, sizingEnabled, variations[] }`; each variation:
  `{ n, status, hookText, duration, hue, failureReason }`.
- `form{}` — New Video local form state: `{ productName, sizeWorn, sizingEnabled, length,
  mode, pacing, variations, styleId, inspirationName, clipCount }`.
- `profile{}` — `{ height, weight }` (persist server-side; feeds sizing overlay).
- `styles[]` — preset catalog (Mixed Cuts, Dupe Flip). Likely server-driven/config.
- `formError`, `toast`, and render timers (replace timers with **polling**: while a job
  isn't `done|failed`, poll `GET /videos/:id` every ~5s — the "refreshing every 5s"
  indicator reflects this).

### Suggested API surface
- `POST /videos` (create job from the form; returns job with `status: pending`)
- `GET /videos` (list) · `GET /videos/:id` (poll while in progress)
- `GET /videos/:id/variations/:n/download` · `GET /videos/:id/download-all` (zip)
- `PUT /profile` (height/weight)
- File uploads for raw clips and the optional inspiration photo (multipart / signed URLs).

---

## Assets
- **Fonts:** Bricolage Grotesque, Manrope, Space Mono (Google Fonts).
- **Icons:** simple inline stroke SVGs (home, play-rect, plus, user, upload, image, clock,
  download, chevrons, mute, warning-triangle, error-circle, info). Swap for your icon lib
  (Lucide/Feather match the 2px-stroke style).
- **Imagery:** none shipped. Video thumbnails/players are CSS gradient placeholders — in
  production these are real muted 9:16 video frames/players.
- **Auth:** Clerk (referenced only; not built here).

## Files in this bundle
- `README.md` — this document (self-sufficient; implement from it alone).
- `Cutloop.dc.html` — the HTML prototype (reference for exact values; not shippable).
- `support.js` — runtime for the prototype format (do not reuse).
- `screenshots/01-home.png … 05-profile.png` — one per screen.
